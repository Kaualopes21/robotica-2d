#include<stdio.h>

int main(){
    Printf("ola mundo\n")

    return 0
}